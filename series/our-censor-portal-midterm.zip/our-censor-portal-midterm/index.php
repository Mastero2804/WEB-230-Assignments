<?php

  $pageTitle = "Home";

  include_once('include/header.inc.php');

?>

<h1>Welcome to our home page.</h1>

<?php

  include_once('include/footer.inc.php');

?>
