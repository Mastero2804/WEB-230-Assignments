<?php

    $menuItems = array('pages' =>
                        array('MenuLink'=>'index.php','MenuName'=>'Home'),
                        array('MenuLink'=>'events.php','MenuName'=>'Events'),
                        array('MenuLink'=>'internal-communications.php','MenuName'=>'Communications')
                   );

 ?>
