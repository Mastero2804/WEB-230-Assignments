<?php

  $events = array(
                  array('Blue Jeans Day','October 12, 2018','All employees may wear jeans to work.'),
                  array('Leave early day','December 22, 2018','All employees may leave work, with pay, at lunch on this day to get started on their holiday plans.'),
                  array('Christmas Holiday Closing','December 23, 2018','December 27, 2018','Our offices will be closed December 23, 2018 through December 27, 2018.')
                );

 ?>
