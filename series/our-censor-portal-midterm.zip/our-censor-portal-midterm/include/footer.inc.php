<?php

  echo "</section>";
  echo '<footer><div class="copy">Copyright &copy; '.date("Y").' '.$companyName.'</div></footer>';
  echo '</body></html>';

 ?>
