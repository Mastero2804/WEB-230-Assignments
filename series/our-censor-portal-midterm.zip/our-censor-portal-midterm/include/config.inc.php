<?php

  error_reporting(E_ALL);

  $companyName = 'Insights';

  $appTitle = $companyName.' | Communications Portal';

?>
