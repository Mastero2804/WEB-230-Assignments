<?php

  include_once('include/config.inc.php');

  echo '<!DOCTYPE html>';
  echo '<html lang="en">';
  echo '     <head>';
  echo '          <meta charset="UTF-8">';
  echo '          <meta name="viewport" content="width=device-width, initial-scale=1.0">';
  echo '          <meta http-equiv="X-UA-Compatible" content="ie=edge">';
  echo '          <title>Document</title>';
  echo '          <link rel="stylesheet" href="assets/css/style.css">';
  echo '     </head>';
  echo '     <body>';
  echo '          <header>';
  echo '               <h1>'.$appTitle.'</h1>';
  echo '               <h2>our connections to our colluges</h2>';
  echo '          </header>';
  echo '          <section>';
 ?>
