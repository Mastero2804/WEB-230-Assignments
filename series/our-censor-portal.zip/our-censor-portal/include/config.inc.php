<?php

  $companyName = 'Insights';

  $appTitle = $companyName.' | Communications Portal';

?>
